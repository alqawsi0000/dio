# Dio Flutter Starter

Arabic RTL mobile POS/accounting starter built with Flutter. Data currently persists locally with `shared_preferences`.

## Run
1. Install Flutter SDK.
2. In this folder, run `flutter pub get`.
3. Run `flutter run`.

## Included
- Dashboard
- Product CRUD form/list/search
- Customer CRUD and customer statement placeholder
- Warehouse, supplier, cashbox, currency management
- Purchases, sales, voucher, and expenses entry screens
- Local persistence

## Not yet production-ready
- Accounting postings and stock movement automation
- Supabase backend/cloud sync and authentication
- Multi-tenant security/RLS
- Barcode camera scanning, receipt printing, PDF/export
- Complete reports, return workflows, permissions, backup

