import 'package:flutter/material.dart';
import 'dio_app.dart';

void main() { WidgetsFlutterBinding.ensureInitialized(); runApp(const DioApp()); }
